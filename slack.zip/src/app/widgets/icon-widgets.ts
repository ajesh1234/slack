import { Component } from '@angular/core';

@Component({
  selector: 'icon-widgets',
  templateUrl: '../widgets/icon-widgets.html'
})

export class IconWidgetsComponent {

  constructor() {
  }

}

