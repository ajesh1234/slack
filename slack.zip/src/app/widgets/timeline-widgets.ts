import { Component } from '@angular/core';

@Component({
  selector: 'timeline-widgets',
  templateUrl: '../widgets/timeline-widgets.html'
})

export class TimelineWidgetsComponent {

  constructor() {
  }

}

