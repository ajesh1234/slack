import { Component } from '@angular/core';

@Component({
  selector: 'user-widgets',
  templateUrl: '../widgets/user-widgets.html'
})

export class UserWidgetsComponent {

  constructor() {
  }

}

