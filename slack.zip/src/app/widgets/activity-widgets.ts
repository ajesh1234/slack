import { Component } from '@angular/core';

@Component({
  selector: 'activity-widgets',
  templateUrl: '../widgets/activity-widgets.html'
})

export class ActivityWidgetsComponent {

  constructor() {
  }

}

