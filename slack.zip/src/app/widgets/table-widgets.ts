import { Component } from '@angular/core';

@Component({
  selector: 'table-widgets',
  templateUrl: '../widgets/table-widgets.html'
})

export class TableWidgetsComponent {

  constructor() {
  }

}

