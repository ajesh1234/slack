import { Component } from '@angular/core';

@Component({
  selector: 'modals',
  templateUrl: '../notifications/modals.html'
})

export class ModalsComponent {

  constructor() {
  }

}
