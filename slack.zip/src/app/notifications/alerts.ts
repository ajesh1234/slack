import { Component } from '@angular/core';

@Component({
  selector: 'alerts',
  templateUrl: '../notifications/alerts.html'
})

export class AlertsComponent {

  constructor() {
  }

}
