import { Component } from '@angular/core';

@Component({
  selector: 'default-forms',
  templateUrl: '../forms/default-forms.html'
})

export class DefaultFormsComponent {

  constructor() {
  }

}
