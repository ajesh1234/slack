import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-createinvites',
  templateUrl: './createinvites.component.html',
  styleUrls: ['./createinvites.component.scss']
})
export class CreateinvitesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
