import { Component } from '@angular/core';

@Component({
  selector: 'create-account',
  templateUrl: '../pages/create-account.html'
})

export class CreateAccountComponent {

  constructor() {
  }

}

