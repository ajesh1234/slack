import { Component } from '@angular/core';

@Component({
  selector: 'subscribe',
  templateUrl: '../pages/subscribe.html'
})

export class SubscribeComponent {

  constructor() {
  }

}

