import { Component } from '@angular/core';

@Component({
  selector: 'contact-us',
  templateUrl: '../pages/contact-us.html'
})

export class ContactUsComponent {

  constructor() {
  }

}

