import { Component } from '@angular/core';

@Component({
  selector: 'unlock-account',
  templateUrl: '../pages/unlock-account.html'
})

export class UnlockAccountComponent {

  constructor() {
  }

}

