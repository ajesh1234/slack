import { Component } from '@angular/core';

@Component({
  selector: 'reset-password',
  templateUrl: '../pages/reset-password.html'
})

export class ResetPasswordComponent {

  constructor() {
  }

}

