import { Component } from '@angular/core';

@Component({
  selector: 'user-profile',
  templateUrl: '../pages/user-profile.html'
})

export class UserProfileComponent {

  constructor() {
  }

}

