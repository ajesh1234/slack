import { Component } from '@angular/core';

@Component({
  selector: 'under-maintenance',
  templateUrl: '../pages/under-maintenance.html'
})

export class UnderMaintenanceComponent {

  constructor() {
  }

}

