import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-teaminfo',
  templateUrl: './teaminfo.component.html',
  styleUrls: ['./teaminfo.component.scss']
})
export class TeaminfoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
