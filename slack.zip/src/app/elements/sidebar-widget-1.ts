import { Component } from '@angular/core';

@Component({
  selector: 'sidebar-widget-1',
  templateUrl: '../elements/sidebar-widget-1.html'
})

export class SidebarWidget1Component {

  constructor() {
  }

}
