import { Component } from '@angular/core';

@Component({
  selector: 'dropdown-tasks',
  templateUrl: '../elements/dropdown-tasks.html'
})

export class DropdownTasksComponent {

  constructor() {
  }

}
