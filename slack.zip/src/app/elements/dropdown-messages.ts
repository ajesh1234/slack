import { Component } from '@angular/core';

@Component({
  selector: 'dropdown-messages',
  templateUrl: '../elements/dropdown-messages.html'
})

export class DropdownMessagesComponent {

  constructor() {
  }

}
