import { Component } from '@angular/core';

@Component({
  selector: 'sample-modals',
  templateUrl: '../elements/sample-modals.html'
})

export class SampleModalsComponent {

  constructor() {
  }

}
