import { Component } from '@angular/core';

@Component({
  selector: 'dropdown-user',
  templateUrl: '../elements/dropdown-user.html'
})

export class DropdownUserComponent {

  constructor() {
  }

}
