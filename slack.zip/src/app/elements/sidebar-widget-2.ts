import { Component } from '@angular/core';

@Component({
  selector: 'sidebar-widget-2',
  templateUrl: '../elements/sidebar-widget-2.html'
})

export class SidebarWidget2Component {

  constructor() {
  }

}
