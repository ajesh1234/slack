import { Component } from '@angular/core';

@Component({
  selector: 'dropdown-flags',
  templateUrl: '../elements/dropdown-flags.html'
})

export class DropdownFlagsComponent {

  constructor() {
  }

}
