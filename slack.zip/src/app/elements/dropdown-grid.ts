import { Component } from '@angular/core';

@Component({
  selector: 'dropdown-grid',
  templateUrl: '../elements/dropdown-grid.html'
})

export class DropdownGridComponent {

  constructor() {
  }

}
