import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-teamname',
  templateUrl: './teamname.component.html',
  styleUrls: ['./teamname.component.scss']
})
export class TeamnameComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
