import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-createname',
  templateUrl: './createname.component.html',
  styleUrls: ['./createname.component.scss']
})
export class CreatenameComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
