import { Component } from '@angular/core';

@Component({
  selector: 'default-tables',
  templateUrl: '../tables/default-tables.html'
})

export class DefaultTablesComponent {

  constructor() {
  }

}
