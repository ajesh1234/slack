import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-confirmemail',
  templateUrl: './confirmemail.component.html',
  styleUrls: ['./confirmemail.component.scss']
})
export class ConfirmemailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
