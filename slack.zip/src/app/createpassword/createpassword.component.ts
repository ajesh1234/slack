import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-createpassword',
  templateUrl: './createpassword.component.html',
  styleUrls: ['./createpassword.component.scss']
})
export class CreatepasswordComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
