import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-createurl',
  templateUrl: './createurl.component.html',
  styleUrls: ['./createurl.component.scss']
})
export class CreateurlComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
