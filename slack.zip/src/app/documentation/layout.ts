import { Component } from '@angular/core';

@Component({
  selector: 'layout',
  templateUrl: '../documentation/layout.html'
})

export class LayoutComponent {

  constructor() {
  }

}
