import { Component } from '@angular/core';

@Component({
  selector: 'code-structure',
  templateUrl: '../documentation/code-structure.html'
})

export class CodeStructureComponent {

  constructor() {
  }

}
