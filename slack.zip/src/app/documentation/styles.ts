import { Component } from '@angular/core';

@Component({
  selector: 'styles',
  templateUrl: '../documentation/styles.html'
})

export class StylesComponent {

  constructor() {
  }

}
