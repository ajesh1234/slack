import { Component } from '@angular/core';

@Component({
  selector: 'installation',
  templateUrl: '../documentation/installation.html'
})

export class InstallationComponent {

  constructor() {
  }

}
