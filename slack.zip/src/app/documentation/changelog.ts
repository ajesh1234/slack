import { Component } from '@angular/core';

@Component({
  selector: 'changelog',
  templateUrl: '../documentation/changelog.html'
})

export class ChangelogComponent {

  constructor() {
  }

}
