import { Component } from '@angular/core';

@Component({
  selector: 'angular-cli',
  templateUrl: '../documentation/angular-cli.html'
})

export class AngularCliComponent {

  constructor() {
  }

}
