import { Component } from '@angular/core';

@Component({
  selector: 'credits',
  templateUrl: '../documentation/credits.html'
})

export class CreditsComponent {

  constructor() {
  }

}
