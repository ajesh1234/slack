import { Component } from '@angular/core';

@Component({
  selector: 'customization',
  templateUrl: '../documentation/customization.html'
})

export class CustomizationComponent {

  constructor() {
  }

}
