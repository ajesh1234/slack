import { Component } from '@angular/core';

@Component({
  selector: 'breadcrumbs',
  templateUrl: '../ui-elements/breadcrumbs.html'
})

export class BreadcrumbsComponent {

  constructor() {
  }

}
