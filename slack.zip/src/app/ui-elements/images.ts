import { Component } from '@angular/core';

@Component({
  selector: 'images',
  templateUrl: '../ui-elements/images.html'
})

export class ImagesComponent {

  constructor() {
  }

}
