import { Component } from '@angular/core';

@Component({
  selector: 'progress-bars',
  templateUrl: '../ui-elements/progress-bars.html'
})

export class ProgressBarsComponent {

  constructor() {
  }

}
