import { Component } from '@angular/core';

@Component({
  selector: 'buttons',
  templateUrl: '../ui-elements/buttons.html'
})

export class ButtonsComponent {

  constructor() {
  }

}
