import { Component } from '@angular/core';

@Component({
  selector: 'lists',
  templateUrl: '../ui-elements/lists.html'
})

export class ListsComponent {

  constructor() {
  }

}
