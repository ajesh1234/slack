import { Component } from '@angular/core';

@Component({
  selector: 'typography',
  templateUrl: '../ui-elements/typography.html'
})

export class TypographyComponent {

  constructor() {
  }

}
