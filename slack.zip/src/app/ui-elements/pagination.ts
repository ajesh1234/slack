import { Component } from '@angular/core';

@Component({
  selector: 'pagination',
  templateUrl: '../ui-elements/pagination.html'
})

export class PaginationComponent {

  constructor() {
  }

}
