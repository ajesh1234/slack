import { Component } from '@angular/core';

@Component({
  selector: 'badges',
  templateUrl: '../ui-elements/badges.html'
})

export class BadgesComponent {

  constructor() {
  }

}
