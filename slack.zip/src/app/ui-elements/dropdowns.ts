import { Component } from '@angular/core';

@Component({
  selector: 'dropdowns',
  templateUrl: '../ui-elements/dropdowns.html'
})

export class DropdownsComponent {

  constructor() {
  }

}
