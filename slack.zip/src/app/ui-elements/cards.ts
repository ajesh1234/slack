import { Component } from '@angular/core';

@Component({
  selector: 'cards',
  templateUrl: '../ui-elements/cards.html'
})

export class CardsComponent {

  constructor() {
  }

}
