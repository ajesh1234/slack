import { Component } from '@angular/core';

@Component({
  selector: 'social-media-buttons',
  templateUrl: '../ui-elements/social-media-buttons.html'
})

export class SocialMediaButtonsComponent {

  constructor() {
  }

}
