import { Component } from '@angular/core';

@Component({
  selector: 'animation-delays',
  templateUrl: '../extras/animation-delays.html'
})

export class AnimationDelaysComponent {

  constructor() {
  }

}
