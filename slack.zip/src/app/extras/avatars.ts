import { Component } from '@angular/core';

@Component({
  selector: 'avatars',
  templateUrl: '../extras/avatars.html'
})

export class AvatarsComponent {

  constructor() {
  }

}
